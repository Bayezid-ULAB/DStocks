package com.example.dstock;

import android.os.Parcel;
import android.os.Parcelable;

public class Company implements Parcelable {
    private String code;
    private String name;
    private double ltp;
    private double change;
    private double changeP;
    Company(String code, double ltp, double change, double changeP){
        this.code=code;
        this.name=name;
        this.ltp=ltp;
        this.change=change;
        this.changeP=changeP;
    }
    @Override
    public int describeContents() {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int arg1) {
        // TODO Auto-generated method stub
        dest.writeString(code);
        dest.writeString(name);
        dest.writeDouble(ltp);
        dest.writeDouble(change);
        dest.writeDouble(changeP);
    }
    public Company(Parcel in) {
        code = in.readString();
        name = in.readString();
        ltp=in.readDouble();
        change=in.readDouble();
        changeP=in.readDouble();
    }

    public static final Creator<Company> CREATOR = new Creator<Company>() {
        public Company createFromParcel(Parcel in) {
            return new Company(in);
        }

        public Company[] newArray(int size) {
            return new Company[size];
        }
    };
    public String getName() {
        return name;
    }

    public Double getLtp() {
        return ltp;
    }

    public Double getChange() {
        return change;
    }

    public Double getChangeP() {
        return changeP;
    }

    public String getCode() {
        return code;
    }
    public void setName(String name) {
        this.name=name;
    }
}
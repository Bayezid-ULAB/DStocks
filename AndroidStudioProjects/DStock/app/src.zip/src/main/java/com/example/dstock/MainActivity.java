package com.example.dstock;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.IMarker;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.listener.ChartTouchListener;
import com.github.mikephil.charting.listener.OnChartGestureListener;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;


public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, OnChartGestureListener, OnChartValueSelectedListener {

    @Override
    public void onChartGestureStart(MotionEvent me, ChartTouchListener.ChartGesture lastPerformedGesture) {

    }

    @Override
    public void onChartGestureEnd(MotionEvent me, ChartTouchListener.ChartGesture lastPerformedGesture) {

    }

    @Override
    public void onChartLongPressed(MotionEvent me) {

    }

    @Override
    public void onChartDoubleTapped(MotionEvent me) {

    }

    @Override
    public void onChartSingleTapped(MotionEvent me) {

    }

    @Override
    public void onChartFling(MotionEvent me1, MotionEvent me2, float velocityX, float velocityY) {

    }

    @Override
    public void onChartScale(MotionEvent me, float scaleX, float scaleY) {

    }

    @Override
    public void onChartTranslate(MotionEvent me, float dX, float dY) {

    }

    @Override
    public void onValueSelected(Entry e, Highlight h) {

    }

    @Override
    public void onNothingSelected() {

    }

    class dateAndValue{
        private String date;
        private double values;
        dateAndValue(String d,double v){
            this.date=d;
            this.values=v;
        }

        public String getDate() {
            return date;
        }


        public double getValues() {
            return values;
        }
    }
    private DrawerLayout myDrawer;
    private String lastUpdate;
    private double ltp,change,changeP;
    private ActionBarDrawerToggle mytoggle;
    public  static TextView x1,x2,x3,s1,s2,s3,t1,t2,t3,tr1,tr2,tr3,i1,i2,i3,heading;
    private LineGraphSeries<DataPoint> series;
    private static final String TAG="MainActivity";
    private EditText searchText;
    private ArrayList<Company> companyList=new ArrayList<Company>();
    private String activityCurrent;
    private long backPressedTime;
    private Toast backToast;

    private ArrayList<dateAndValue> valuesDseX=new ArrayList<dateAndValue>();
    private ArrayList<dateAndValue> valuesDseS=new ArrayList<dateAndValue>();
    private ArrayList<dateAndValue> valuesDse30=new ArrayList<dateAndValue>();

    static LineChart mChart;


    String[] splited;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mainCall();

        new Content().execute();
    }


    @Override
    public void onBackPressed(){
        if (backPressedTime + 2000 > System.currentTimeMillis()) {
            backToast.cancel();
            super.onBackPressed();
        } else {
            backToast = Toast.makeText(getBaseContext(), "Press back again to exit", Toast.LENGTH_SHORT);
            backToast.show();
            myDrawer.openDrawer(Gravity.LEFT);
            //myDrawer.openDrawer(myDrawer);
        }

        backPressedTime = System.currentTimeMillis();
    }

    private void mainCall(){
        activityCurrent="main";
        setContentView(R.layout.activity_main);
        t1=findViewById(R.id.t1);
        t2=findViewById(R.id.t2);
        t3=findViewById(R.id.t3);
        tr1=findViewById(R.id.tr1);
        tr2=findViewById(R.id.tr2);
        tr3=findViewById(R.id.tr3);
        s3=findViewById(R.id.s3);
        s2=findViewById(R.id.s2);
        s1=findViewById(R.id.s1);
        x1=findViewById(R.id.x1);
        x2=findViewById(R.id.x2);
        x3=findViewById(R.id.x3);
        i1=findViewById(R.id.i1);
        i2=findViewById(R.id.i2);
        i3=findViewById(R.id.i3);
        heading=findViewById(R.id.heading);
        mChart=(LineChart)findViewById(R.id.lineChart);


        new HomeContent().execute();
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(Color.BLACK));
        myDrawer=(DrawerLayout)findViewById(R.id.drawer);
        mytoggle=new ActionBarDrawerToggle(this,myDrawer,R.string.open,R.string.close){
            public void onDrawerClosed(View view) {
                getSupportActionBar().setTitle(R.string.app_name);
            }

            public void onDrawerOpened(View drawerView) {
                getSupportActionBar().setTitle("Select Option");
            }
        };



        myDrawer.addDrawerListener(mytoggle);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mytoggle.syncState();
        //getSupportActionBar().setHomeButtonEnabled(true);

        NavigationView navView=findViewById(R.id.navigation);
        navView.setNavigationItemSelectedListener(this);

    }
    private Context getContext(){
        return this;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(mytoggle.onOptionsItemSelected(item))return true;
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        int id=item.getItemId();
        if(id==R.id.atoz){
            if(activityCurrent!="companyList"){
                companyListCalled();
                myDrawer.closeDrawers();
            }
            else myDrawer.closeDrawers();
        }
        else if(id==R.id.favorites){
            if(activityCurrent!="favorite"){
                favoriteCalled();
                myDrawer.closeDrawers();
            }
            else myDrawer.closeDrawers();
        }
        else if(id==R.id.top20){
            if(activityCurrent!="top20"){
                top20Called();
                myDrawer.closeDrawers();
            }
            else myDrawer.closeDrawers();
        }
        else if(id==R.id.home){
            if(activityCurrent!="main"){

                mainCall();
                myDrawer.closeDrawers();
            }
            else myDrawer.closeDrawers();
        }
        else if (id == R.id.settings){
            if(activityCurrent!="settings"){

            settingsCalled();
            myDrawer.closeDrawers();
        }
        else myDrawer.closeDrawers();

        }
        return false;
    }

    private void settingsCalled(){
        setContentView(R.layout.activity_settings);
        activityCurrent="settings";
        getSupportActionBar().setTitle("My Settings");
        myDrawer=(DrawerLayout)findViewById(R.id.drawerCompany);
        mytoggle=new ActionBarDrawerToggle(this,myDrawer,R.string.open,R.string.close){
            public void onDrawerClosed(View view) {
                getSupportActionBar().setTitle("My Settings");
            }

            public void onDrawerOpened(View drawerView) {
                getSupportActionBar().setTitle("Select Option");
            }
        };

        myDrawer.addDrawerListener(mytoggle);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mytoggle.syncState();
        NavigationView navView=findViewById(R.id.navigationCompany);
        navView.setNavigationItemSelectedListener(this);

    }
    private void favoriteCalled(){setContentView(R.layout.activity_top);
        setContentView(R.layout.activity_favorite);
        activityCurrent="favorite";
        getSupportActionBar().setTitle("My Favorites");
        myDrawer=(DrawerLayout)findViewById(R.id.drawerCompany);
        mytoggle=new ActionBarDrawerToggle(this,myDrawer,R.string.open,R.string.close){
            public void onDrawerClosed(View view) {
                getSupportActionBar().setTitle("My Favorites");
            }

            public void onDrawerOpened(View drawerView) {
                getSupportActionBar().setTitle("Select Option");
            }
        };

        myDrawer.addDrawerListener(mytoggle);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mytoggle.syncState();
        NavigationView navView=findViewById(R.id.navigationCompany);
        navView.setNavigationItemSelectedListener(this);

    }
    private void top20Called(){
        setContentView(R.layout.activity_top);
        activityCurrent="top20";
        getSupportActionBar().setTitle("Top 20 Shares");
        myDrawer=(DrawerLayout)findViewById(R.id.drawerCompany);
        mytoggle=new ActionBarDrawerToggle(this,myDrawer,R.string.open,R.string.close){
            public void onDrawerClosed(View view) {
                getSupportActionBar().setTitle("Top 20 Shares");
            }

            public void onDrawerOpened(View drawerView) {
                getSupportActionBar().setTitle("Select Option");
            }
        };

        myDrawer.addDrawerListener(mytoggle);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mytoggle.syncState();
        NavigationView navView=findViewById(R.id.navigationCompany);
        navView.setNavigationItemSelectedListener(this);

    }
    private void companyListCalled(){

        setContentView(R.layout.activity_company_list);
        activityCurrent="companyList";
        getSupportActionBar().setTitle("Company List");
        myDrawer=(DrawerLayout)findViewById(R.id.drawerCompany);

        mytoggle=new ActionBarDrawerToggle(this,myDrawer,R.string.open,R.string.close){
            public void onDrawerClosed(View view) {
                getSupportActionBar().setTitle("Company List");
            }

            public void onDrawerOpened(View drawerView) {
                getSupportActionBar().setTitle("Select Option");
            }
        };

        myDrawer.addDrawerListener(mytoggle);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mytoggle.syncState();
        NavigationView navView=findViewById(R.id.navigationCompany);
        navView.setNavigationItemSelectedListener(this);


        final ListView myList=findViewById(R.id.companyList);

        //TextView stv=findViewById(R.id.sTv);
        final CompanyListAdapter adapter=new CompanyListAdapter(this, R.layout.adapter_view,companyList);
        myList.setAdapter(adapter);
        myList.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> parentAdapter, View view, int position,
                                    long id) {


                // We know the View is a <extView so we can cast it
                Company selItem = (Company) adapter.getItem(position);
                Toast.makeText(getContext(), "Company Code: "+selItem.getCode() +" "+position, Toast.LENGTH_SHORT).show();
                Intent a=new Intent(getContext(),CompanyInfo.class);
                startActivity(a);

            }
        });



        searchText=findViewById(R.id.search);
        searchText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (count < before) {
                    // We're deleting char so we need to reset the adapter data
                    adapter.resetData();
                }

                adapter.getFilter().filter(s.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

    }



    private class Content extends AsyncTask<Void, Void, Void> {
        public void writeFileOnInternalStorage(Context mcoContext,String sFileName, String sBody){
            File file = new File(mcoContext.getFilesDir(),"mydir");
            if(!file.exists()){
                file.mkdir();
            }

            try{
                File gpxfile = new File(file, sFileName);
                FileWriter writer = new FileWriter(gpxfile);
                writer.append(sBody);
                writer.flush();
                writer.close();

            }catch (Exception e){
                e.printStackTrace();

            }
        }        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }


        @Override
        protected Void doInBackground(Void... voids) {
            try{
               // Document companyNames=Jsoup.connect("http://dsebd.org/company%20listing.php").get();
                //String companyName;

                Document company = Jsoup.connect("http://www.dsebd.org/company%20listing.php").get();

                Elements importantLinks = company.getElementsByClass("abhead");
                for (Element link : importantLinks.select("a")) {
                    String linkText = link.text(); //THIS IS THE TEXT I WANTED...
                    if (linkText.toUpperCase().equals(linkText) && !linkText.contains("T20") && !linkText.contains("T05") && !linkText.contains("T10") && !linkText.contains("T15") && !linkText.contains("T5") && linkText.length() > 1) {
                        splited = linkText.split("\\s+");
                        String name = splited[0];


                  //      Pattern p = Pattern.compile(".*\\(*(.*) *\\).*");
                  //      Matcher m = p.matcher(companyNames.toString());
                  //      while(m.find())
                   //     {
                   //         String text = m.group(1);
                   //         System.out.println(text); //is your string. do what you want
                    //    }
                        try {
                            ltp = Double.parseDouble(splited[1]);

                        } catch (Exception ex) {

                        }

                        try {
                            change = Double.parseDouble(splited[2]);
                        } catch (Exception ex) {

                        }

                        try {
                            changeP = Double.parseDouble(splited[3].replace("%", ""));

                        } catch (Exception ex) {

                        }
                        companyList.add(new Company(name, ltp, change, changeP));
                        //System.out.println(name);

                    }

                }
                if(companyList.size()==0)companyList.add(new Company("AAMRANET",15.5,-2.2,-2.01));
                importantLinks = company.getElementsByTag("font");
                for (Element link : importantLinks) {
                   if (link.text().toString().contains("(")) {
                        String linkText = link.text().toString().substring((link.text().toString().indexOf('(') + 1),link.text().toString().lastIndexOf(')'));
                        String code=link.text().toString().substring(0,link.text().toString().lastIndexOf('(')-1);

                        //System.out.println(linkText+"+"+code);//THIS IS THE TEXT I WANTED...
                        if (code.toUpperCase().equals(code) && !code.contains("T20") && !code.contains("T05") && !code.contains("T10") && !code.contains("T15") && !code.contains("T5") && code.length() > 1) {
                            String name = linkText;
                            //System.out.println(name);
                            for(Company a:companyList){
                                if(a.getCode().toString().equals(code.toString())){
                                    a.setName(name);
                                    //System.out.println("Company Name: "+a.getName()+"\nCompany Code:"+a.getCode());
                                    break;
                                }
                            }

                            //companyList.add(new Company(name, ltp, change, changeP));
                            //System.out.println(name);

                        }


                    }

                }

            }catch (IOException e){
            }

            //Toast.makeText(getContext(),valuesDse30.get(0).toString(),Toast.LENGTH_SHORT).show();
            return null;

        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }

    private class HomeContent extends AsyncTask<Void, Void, Void> {
        private String x1,x2,x3,s1,s2,s3,t1,t2,t3,tr1,tr2,tr3,i1,i2,i3,heading;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }


        @Override
        protected Void doInBackground(Void... voids) {
            try{
                Document company = Jsoup.connect("http://www.dsebd.org").get();

                Elements importantLinks = company.getElementsByClass("m_col-2");
                int i=0;
                for(Element data:importantLinks){
                    if(i==0)x1=data.text().toString();
                    else if(i==1)s1=data.text().toString();
                    else if(i==2){
                        t1=data.text().toString();
                        break;
                    }
                    i++;
                }


                importantLinks = company.getElementsByClass("m_col-3");
                i=0;
                for(Element data:importantLinks){
                    if(i==0)x2=data.text().toString();
                    else if(i==1)s2=data.text().toString();
                    else if(i==2){
                        t2=data.text().toString();
                        break;
                    }
                    i++;
                }


                importantLinks = company.getElementsByClass("m_col-4");
                i=0;
                for(Element data:importantLinks){
                    if(i==0)x3=data.text().toString();
                    else if(i==1)s3=data.text().toString();
                    else if(i==2){
                        t3=data.text().toString();
                        break;
                    }
                    i++;
                }
                importantLinks = company.getElementsByClass("m_col-wid colorlight");
                i=0;
                for(Element data:importantLinks){
                    if(i==0)tr1=data.text().toString();
                    else if(i==1){
                        i1=data.text();
                        break;
                    }
                    i++;
                }
                importantLinks = company.getElementsByClass("m_col-wid1 colorlight");
                i=0;

                for(Element data:importantLinks){
                    if(i==0) tr2=data.text().toString();
                    else if(i==1){
                        i2=data.text();
                        break;
                    }
                    i++;
                }
                importantLinks = company.getElementsByClass("m_col-wid2 colorlight");
                i=0;

                for(Element data:importantLinks){
                    if(i==0) tr3=data.text().toString();
                    else if(i==1){
                        i3=data.text();
                        break;
                    }
                    i++;
                }
                importantLinks = company.getElementsByClass("Bodyheading");

                for(Element data:importantLinks){
                    heading=data.text().toString();
                    break;
                }

            }catch (IOException e){
            }


            return null;

        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            MainActivity.x1.setText(x1);
            MainActivity.s1.setText(s1);
            MainActivity.t1.setText(t1);
            MainActivity.i1.setText(i1);
            MainActivity.i2.setText(i2);
            MainActivity.i3.setText(i3);
            MainActivity.x2.setText(x2);
            MainActivity.s2.setText(s2);
            MainActivity.t2.setText(t2);
            MainActivity.x3.setText(x3);
            MainActivity.s3.setText(s3);
            MainActivity.t3.setText(t3);
            MainActivity.tr1.setText(tr1);
            MainActivity.tr2.setText(tr2);
            MainActivity.tr3.setText(tr3);
            MainActivity.heading.setText(heading);
            ArrayList<Entry> yvalues=new ArrayList<Entry>();

        }
    }
}